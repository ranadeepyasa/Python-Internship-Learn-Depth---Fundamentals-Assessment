def addition(a, b):
    return a + b


def subtraction(a, b):
    return a - b


def multiplication(a, b):
    return a * b


def division(a, b):
    return a / b


num1 = float(input("Enter first number: "))
num2 = float(input("Enter second number: "))

print("Choose an operation:")
print("+ for Addition")
print("- for Subtraction")
print("* for Multiplication")
print("/ for Division")

operator = input("Enter operator: ")

if operator == "+":
    print("Result:", addition(num1, num2))
elif operator == "-":
    print("Result:", subtraction(num1, num2))
elif operator == "*":
    print("Result:", multiplication(num1, num2))
elif operator == "/":
    if num2 != 0:
        print("Result:", division(num1, num2))
    else:
        print("Error: Cannot divide by zero")
else:
    print("Invalid operator")
